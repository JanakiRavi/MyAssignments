package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends ProjectSpecificMethod{
	
	
	@Then("ViewLeads page should be displayed as (.*)$")
	public ViewLeadPage verifyLeadname(String cname) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cname)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
		return this;
	}
	@And("Click on the Edit button")
	public EditLeadPage clickEditButton() {
		driver.findElement(By.linkText("Edit")).click();
		return new EditLeadPage();
	}
	@Then("ViewLeads page should be displayed with company name as (.*)$")
	public ViewLeadPage verifyEditLead(String cname) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cname)) {
			System.out.println("Lead is editted successfully");
		}
		else {
			System.out.println("Lead is not editted");
		}
		return this;
	}
	@And("Click on Delete button")
	public MyLeadsPage clickDelete() {
		driver.findElement(By.linkText("Delete")).click();
		return new MyLeadsPage();
	}
}
