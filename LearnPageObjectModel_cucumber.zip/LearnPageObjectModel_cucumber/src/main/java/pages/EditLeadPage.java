package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class EditLeadPage extends ProjectSpecificMethod{

	@And("Enter the company name to edit as (.*)$")
   public EditLeadPage editCompanyname(String editcname) {
	   WebElement companyName = driver.findElement(By.id("updateLeadForm_companyName"));
		companyName.clear();
		companyName.sendKeys(editcname);
		return this;
	   
   }
	@When("Click on Update button")
   public ViewLeadPage clickUpdate() {
	   driver.findElement(By.name("submitButton")).click();
	   return new ViewLeadPage();
   }
}
