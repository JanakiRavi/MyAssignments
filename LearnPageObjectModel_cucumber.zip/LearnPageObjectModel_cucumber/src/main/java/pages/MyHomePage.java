package pages;

import org.openqa.selenium.By;
import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;

public class MyHomePage extends ProjectSpecificMethod{
	
@And("Click on Leads link")
public MyLeadsPage clickLeads() {
	 driver.findElement(By.linkText("Leads")).click();
   return new MyLeadsPage();
 }
}
