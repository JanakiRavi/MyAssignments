package pages;

import org.openqa.selenium.By;
import base.ProjectSpecificMethod;
import io.cucumber.java.en.*;

public class CreateLeadPage extends ProjectSpecificMethod{
	@Given("Enter the companyName as (.*)$")
	public CreateLeadPage entercomapny(String cname) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cname);
		return this;
	}
	@And("Enter the firstName as (.*)$")
	public CreateLeadPage enterfirstname(String fname) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		return this;
	}
	@And("Enter the lastName as (.*)$")
	public CreateLeadPage enterlastname(String lname) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		return this;
	}
	@And("Enter the phone number as (.*)$")
	public CreateLeadPage enterphone(String phone) {
		driver.findElement(By.id("createLeadForm_primaryPhoneNumber")).sendKeys(phone);
		return this;
	}
	@When("Click on submit button")
	public ViewLeadPage clickCreateLeadButton() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadPage();
	}
}
