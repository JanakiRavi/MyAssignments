package pages;

import org.openqa.selenium.By;
import base.ProjectSpecificMethod;
import io.cucumber.java.en.*;

public class WelcomePage extends ProjectSpecificMethod{
	@Then("HomePage should be displayed")
	public WelcomePage verifyHomePage() {
		String title = driver.getTitle();
		if (title.contains("Leaftaps")) {
			System.out.println("Login successfull");
		}
		else {
			System.out.println("Login not successfull");
		}
		return this;
	}
	@When("Click on CRMSFA link")
	public MyHomePage clickcrmsfa() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	
}
