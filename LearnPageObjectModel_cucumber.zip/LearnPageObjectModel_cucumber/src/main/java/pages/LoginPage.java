package pages;

import org.openqa.selenium.By;
import base.ProjectSpecificMethod;
import io.cucumber.java.en.*;

public class LoginPage extends ProjectSpecificMethod{
	@Given("Enter the username as {string}")
	public LoginPage enterUserName(String uname) {
		driver.findElement(By.id("username")).sendKeys(uname);
	return this;
	}
	@And("Enter the password as {string}")
	public LoginPage enterPassword(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	@When("Click on Login button")
	public WelcomePage clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new WelcomePage();
		
	}
	
}
