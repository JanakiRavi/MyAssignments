package pages;

import org.openqa.selenium.By;
import base.ProjectSpecificMethod;
import io.cucumber.java.en.*;

public class MyLeadsPage extends ProjectSpecificMethod{
	@And("Click on CreateLead link")
	public CreateLeadPage clickCreateLead() {
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
	@And("Click on Find Leads link")
	public FindLeadsPage clickFindLead() {
		driver.findElement(By.linkText("Find Leads")).click();
		return new FindLeadsPage();
	}

}
