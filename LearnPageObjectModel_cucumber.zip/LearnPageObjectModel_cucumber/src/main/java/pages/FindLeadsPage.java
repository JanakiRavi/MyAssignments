package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.*;


public class FindLeadsPage extends ProjectSpecificMethod{

	@And("Click on Phone tab")
	public FindLeadsPage clickPhone() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		return this;
	}
	@Given("Enter the phone number to find lead as (.*)$")
    public FindLeadsPage enterphonenum(String phone) {
    	driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phone);
    	return this;
    }
	@When("Click on Find Leads button")
    public FindLeadsPage clickFindLeadsButton() {
    	driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
    	return this;
    }
	@And("Click on the first Lead from the results")
    public ViewLeadPage clickFirstLead() throws InterruptedException {
		Thread.sleep(2000);
		LeadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new ViewLeadPage();
    }
	@And("Enter captured Lead Id")
	public FindLeadsPage enterLeadId() {
    	driver.findElement(By.xpath("//input[@name='id']")).sendKeys(LeadID);
    	return this;
    }
	@Then("Verify no results are displayed")
    public FindLeadsPage verifyLead() {
    	String text = driver.findElement(By.className("x-paging-info")).getText();
		if (text.equals("No records to display")) {
			System.out.println("Lead deleted successfully");
		} else {
			System.out.println("Lead is not deleted ");
		}
		return this;
    }
}
