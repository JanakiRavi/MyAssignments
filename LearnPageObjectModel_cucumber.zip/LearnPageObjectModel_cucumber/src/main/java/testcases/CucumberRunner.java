package testcases;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features="src/main/java/features/TC005_DeleteLead.feature",glue="pages"
							,monochrome = true,publish=true)	
public class CucumberRunner extends ProjectSpecificMethod{

}
