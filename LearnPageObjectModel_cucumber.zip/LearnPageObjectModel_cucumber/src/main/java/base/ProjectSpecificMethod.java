package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;



public class ProjectSpecificMethod extends AbstractTestNGCucumberTests{
	public  static ChromeDriver driver; 
	//cucumber does not support parallel exceution, so use static for sequential execution
	//cucumber does not support read excel, so give data in Examples in feature file
	public String excelFileName;
	public static String LeadID;
	@BeforeMethod
	public void precondition() {
		driver  = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@AfterMethod
	public void postcondition() {

		driver.close();
	}
}
