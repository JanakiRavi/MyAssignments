package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunEditLead extends ProjectSpecificMethod{

	
	@Test
	public void runCreateLead() throws  InterruptedException {
		LoginPage lp = new LoginPage();
		lp.enterUserName().enterPassword().clickLoginButton().verifyHomePage()
		.clickcrmsfa().clickLeads().clickFindLead().clickPhone().enterphonenum("91")
		.clickFindLeadsButton().clickFirstLead().clickEditButton().editCompanyname("TCS").clickUpdate();
        
	}

}
