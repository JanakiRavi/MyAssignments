package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunDuplicateLead extends ProjectSpecificMethod{
	@Test
	public void DuplicateLead() throws  InterruptedException {
		LoginPage lp = new LoginPage();
		lp.enterUserName().enterPassword().clickLoginButton()
		.verifyHomePage().clickcrmsfa().clickLeads().clickFindLead().clickPhone().enterphonenum("99")
		.clickFindLeadsButton().clickFirstLead().clickDuplicateButton().clickReassign();
	}
}
