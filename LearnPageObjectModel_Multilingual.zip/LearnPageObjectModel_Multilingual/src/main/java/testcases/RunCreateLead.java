package testcases;


import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunCreateLead extends ProjectSpecificMethod{

	
	@Test
	public void runCreateLead() throws  InterruptedException {
		LoginPage lp = new LoginPage();
        lp.enterUserName()
        .enterPassword()
        .clickLoginButton()
        .verifyHomePage()
        .clickcrmsfa()
        .clickLeads()
        .clickCreateLead()
        .entercomapny("TestLeaf")
        .enterfirstname("Subraja")
        .enterlastname("Subi")
        .clickCreateLeadButton()
        .verifyLeadname("TestLeaf");
	}
}
