package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class EditLeadPage extends ProjectSpecificMethod{

	
   public EditLeadPage editCompanyname(String editcname) {
	   WebElement companyName = driver.findElement(By.id("updateLeadForm_companyName"));
		companyName.clear();
		companyName.sendKeys(editcname);
		return this;
	   
   }
   public ViewLeadPage clickUpdate() {
	   driver.findElement(By.name("submitButton")).click();
	   return new ViewLeadPage();
   }
}
