package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod{
	
	public ViewLeadPage verifyLeadname(String cName) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cName)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
		return this;
	}
	public EditLeadPage clickEditButton() {
		driver.findElement(By.linkText(prop.getProperty("ViewLeadPage_Edit_linkText"))).click();
		return new EditLeadPage();
	}
	public ViewLeadPage clickDuplicateButton() {
		driver.findElement(By.linkText(prop.getProperty("ViewLeadPage_DupliacteLead_linkText"))).click();
		return new ViewLeadPage();
	}
	public ViewLeadPage verifyEditLead() {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains("TCS")) {
			System.out.println("Lead is editted successfully");
		}
		else {
			System.out.println("Lead is not editted");
		}
		return this;
	}
	public MyLeadsPage clickDeleteButton() {
		driver.findElement(By.linkText("Delete")).click();
		return new MyLeadsPage();
	}
	
	public ViewLeadPage clickReassign() {
		driver.findElement(By.className("smallSubmit")).click();
		return new ViewLeadPage();
	}
}
