package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyLeadsPage extends ProjectSpecificMethod{
	
	public CreateLeadPage clickCreateLead() {
		driver.findElement(By.linkText(prop.getProperty("MyLeadsPage_createLead_linkText"))).click();
		return new CreateLeadPage();
	}
	public FindLeadsPage clickFindLead() {
		driver.findElement(By.linkText(prop.getProperty("MyLeadsPage_FindLeads_linkText"))).click();
		return new FindLeadsPage();
	}

}
