package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class FindLeadsPage extends ProjectSpecificMethod{

	
	public FindLeadsPage clickPhone() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		return this;
	}
    public FindLeadsPage enterphonenum(String phone) {
    	driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phone);
    	return this;
    }
    public FindLeadsPage clickFindLeadsButton() {
    	driver.findElement(By.xpath("//button[text()='Rechercher des prospects']")).click();
    	return this;
    }
    public ViewLeadPage clickFirstLead() throws InterruptedException {
    	Thread.sleep(2000);
		LeadID = driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new ViewLeadPage();
    }
    
}
