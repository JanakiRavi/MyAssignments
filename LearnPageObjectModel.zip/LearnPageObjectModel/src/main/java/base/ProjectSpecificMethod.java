package base;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utilis.ReadExcel;

public class ProjectSpecificMethod {
	public  ChromeDriver driver;
	public String excelFileName;
	public static String LeadID;
	public static List<String> allhandles;
	public static String leadID;

	@BeforeMethod
	public void precondition() {
		driver  = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}
	@AfterMethod
	public void postcondition() {

		driver.close();
	}
	@DataProvider
	public String[][] sendData() throws Exception{
		return ReadExcel.readExcel(excelFileName);
		
	}
}
