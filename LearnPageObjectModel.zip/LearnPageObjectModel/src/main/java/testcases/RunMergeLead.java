package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunMergeLead extends ProjectSpecificMethod{
	@BeforeTest
	public void setvalues() {
		excelFileName="MergeLead";
	}

	@Test(dataProvider="sendData")
	public void runEditLead(String uname,String pwd,String fromname,String toname) throws InterruptedException {
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName(uname).enterPassword(pwd).clickLoginButton().verifyHomePage()
		.clickcrmsfa().clickLeads().clickMergeLead().clickwidgetone().switchcontrol().enterFromFirstName(fromname)
		.clickFLeadButton().clickLeadName().switchToMainWindow().clickLeadWidgettwo().switchcontrol().enterToFirstName(toname)
		.clickFLeadButton().clickLeadName().switchToMainWindow().clickMergeButton().acceptAlert().clickFindLead().enterLeadId()
		.clickFindLeadsButton()
		.verifyMergeLead();
	}
	
	
	
}
