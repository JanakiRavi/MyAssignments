package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunCreateLead extends ProjectSpecificMethod{

	@BeforeTest
	public void setvalues() {
		excelFileName="CreateLead";
	}
	
	@Test(dataProvider="sendData")
	public void runCreateLead(String uname,String pwd,String cname,String fname,String lname,String phone) {
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName(uname).enterPassword(pwd).clickLoginButton().verifyHomePage()
		.clickcrmsfa().clickLeads().clickCreateLead().entercomapny(cname).enterfirstname(fname).enterlastname(lname)
		.enterphone(phone).clickCreateLeadButton().verifyLeadname();
	}
}
