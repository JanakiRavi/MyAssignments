package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class RunDeleteLead extends ProjectSpecificMethod{
	@BeforeTest
	public void setvalues() {
		excelFileName="DeleteLead";
	}
	

	@Test(dataProvider="sendData")
	public void runEditLead(String uname,String pwd,String phone) throws InterruptedException {
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName(uname).enterPassword(pwd).clickLoginButton().verifyHomePage()
		.clickcrmsfa().clickLeads().clickFindLead().clickPhone().enterphonenum(phone)
		.clickFindLeadsButton().clickFirstLead().clickDeleteButton().clickFindLead().enterLeadId()
		.clickFindLeadsButton().verifyDeleteLead();
	}
}


