package pages;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MergeLeadPage extends ProjectSpecificMethod{

	public MergeLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public MergeLeadPage clickwidgetone() {
		driver.findElement(By.xpath("//img[@alt='Lookup']")).click();
		return this;
	}
    public MergeLeadPage switchcontrol() {
    	allhandles= new ArrayList<String>(driver.getWindowHandles());
    	 driver.switchTo().window(allhandles.get(1));
    	 return this;
    }
    public MergeLeadPage enterFromFirstName(String fFirstName) {
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(fFirstName);
		return this;
	}
    public MergeLeadPage clickFLeadButton() {
    	driver.findElement(By.xpath("//button[@type='button']")).click();
    	return this;
    }
    public MergeLeadPage clickLeadName() throws InterruptedException {
    	Thread.sleep(3000);
    	LeadID=driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).getText();
		 driver.findElement(By.xpath("(//a[@class='linktext'])[3]")).click();
			//System.out.println("name clicked");
		 return this;
	}
    public MergeLeadPage switchToMainWindow() {
		driver.switchTo().window(allhandles.get(0));
		return this;
	}
   
   
    public MergeLeadPage clickLeadWidgettwo() {
		driver.findElement(By.xpath("(//img[@alt='Lookup'])[2]")).click();
	
		return this;
	}
    public MergeLeadPage enterToFirstName(String tFirstName) {
		driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(tFirstName);
		return this;
	}
    public MergeLeadPage clickMergeButton() {
		driver.findElement(By.xpath("//a[text()='Merge']")).click();
		//System.out.println("merge clicked");
		return this;
	}
    
    public MyLeadsPage acceptAlert() {
		driver.switchTo().alert().accept();
		return new MyLeadsPage(driver);
	}

    
}
